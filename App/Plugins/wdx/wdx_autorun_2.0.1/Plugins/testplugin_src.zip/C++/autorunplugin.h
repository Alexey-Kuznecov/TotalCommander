#pragma once

typedef int (__stdcall * PluginProc)(LPVOID);		// prototype of plugin function
typedef int (__stdcall * MacroProc)(LPWSTR, DWORD);	// prototype of macro function
typedef int (__stdcall * APIProc)(UINT, LPVOID);	// prototype of API adapter function

typedef struct tagAutorunInterface
{
	DWORD	dwSize;		// struct size
	HWND	hWnd;		// TC window handle
	LPVOID	lpAdapter;	// pointer to adapter function
} AutorunInterface;

 // parameters for plugin functions
typedef struct tagAutorunFuncParams
{
	DWORD	dwSize;		// struct size
	LPCWSTR	Param;		// parameters string
	LPWSTR	Value;		// return value
	DWORD	dwBufSize;	// return value buffer size in BYTES
	INT		nError;		// user error value (non-fatal)
} AutorunFuncParams;

// structure for setting functions
typedef struct tagPluginFuncInfo
{
	DWORD	dwSize;		// struct size
	DWORD	dwFlags;	// function flags
	LPCWSTR	lpFuncName;	// name of function
	LPVOID	lpFuncAddr;	// function address
} PluginFuncInfo;

typedef struct tagVarInfo
{
	DWORD	dwSize;		// struct size
	DWORD	dwFlags;	// variable flags
	LPCWSTR	lpName;		// variable name
	LPVOID	lpData;		// variable value, buffer or function address
	DWORD	dwBufSize;	// buffer size in BYTES
} VarInfo;

// Error reporting
typedef struct tagErrorReport
{
	DWORD	dwSize;	// struct size
	INT	nMsgID;		// message ID
	LPCWSTR	lpText;	// message text / std param
	INT nFlags;		// reserved for future use
} ErrorReport;

// common record for API functions that receive data
typedef struct tagGetData
{
	LPWSTR	lpText;		// text/name/caption
	LPWSTR	lpBuffer;	// buffer
	DWORD	dwBufSize;	// buffer size in BYTES
} ExpVars, ParseNextData;

// common result
#define AU_RESULT_OK	0
#define AU_RESULT_ERROR	1

// API function return values (error codes)
#define AU_RESULT_VARNOEXIST		2
#define AU_RESULT_NOREDEFINECONST	3

// Parser function return values
#define AU_PARSER_NOMOREPARAMS	0
#define AU_PARSER_REGULARPARAM	1
#define AU_PARSER_NAMEDPARARAM	2

// Flags for set variables proc
#define AU_VAR_CONSTANT	1
#define AU_VAR_MACRO	2

// Flags for set functions proc
#define AU_FUNC_RETURNVALUE	1
#define AU_FUNC_BOOLEAN		2

// Indexes of API functions
#define AU_PROC_ADDFUNC		1
#define AU_PROC_PARSER_NEXT	2
#define AU_PROC_GETVAR		3
#define AU_PROC_SETVAR		4
#define AU_PROC_EXPANDVARS	5
#define AU_PROC_REPORTERROR	6

#define AU_ERR_USERMSG		0
#define AU_ERR_UNSUPPORTED	4

LPVOID Adapter;

int SetVar(LPWSTR AName, LPWSTR AValue, int AFlags)
{
  APIProc Proc = (APIProc)Adapter;

  VarInfo Info;
  Info.dwSize		= sizeof(VarInfo);
  Info.dwFlags		= AFlags;
  Info.lpName		= AName;
  Info.lpData		= AValue;
  Info.dwBufSize	= 0;

  return Proc(AU_PROC_SETVAR, &Info);
}

int GetVar(LPWSTR AVarName, LPWSTR lpBuffer, UINT nBufferSize)
{
  APIProc Proc = (APIProc)Adapter;

  VarInfo Info;
  Info.dwSize		= sizeof(VarInfo);
  Info.lpName		= AVarName;
  Info.lpData		= lpBuffer;
  Info.dwBufSize	= nBufferSize;

  return Proc(AU_PROC_GETVAR, &Info);
}

int SetVarMacro(LPWSTR AName, LPVOID AFuncAddr)
{
  APIProc Proc = (APIProc)Adapter;

  VarInfo Info;
  Info.dwSize		= sizeof(VarInfo);
  Info.dwFlags		= AU_VAR_MACRO;
  Info.lpName		= AName;
  Info.lpData		= AFuncAddr;
  Info.dwBufSize	= 0;

  return Proc(AU_PROC_SETVAR, &Info);
}

int AddFunc(LPWSTR AName, LPVOID AAddr, int AFlags)
{
  APIProc Proc = (APIProc)Adapter;

  PluginFuncInfo Info;
  Info.dwSize		= sizeof(PluginFuncInfo);
  Info.dwFlags		= AFlags;
  Info.lpFuncName	= AName;
  Info.lpFuncAddr	= AAddr;

  return Proc(AU_PROC_ADDFUNC, &Info);
}

int ParseNext(LPWSTR AParamStr, LPWSTR ABuffer, DWORD nBufSize)
{
  APIProc Proc = (APIProc)Adapter;

  ParseNextData Data;
  Data.lpText		= AParamStr;
  Data.lpBuffer		= ABuffer;
  Data.dwBufSize	= nBufSize;

  return Proc(AU_PROC_PARSER_NEXT, &Data);
}

int ExpandVars(LPWSTR AText, LPWSTR ABuffer, DWORD nBufSize)
{
  APIProc Proc = (APIProc)Adapter;

  ExpVars Data;
  Data.lpText		= AText;
  Data.lpBuffer		= ABuffer;
  Data.dwBufSize	= nBufSize;

  return Proc(AU_PROC_EXPANDVARS, &Data);
}

int ReportError(INT MsgID, LPCWSTR aParam)
{
  APIProc Proc = (APIProc)Adapter;

  ErrorReport Data;
  Data.dwSize   = sizeof(ErrorReport);
  Data.nMsgID   = MsgID;
  Data.lpText   = aParam;
  Data.nFlags   = 0;

  return Proc(AU_PROC_REPORTERROR, &Data);
}

int ReportError(LPCWSTR aText)
{
	return ReportError(AU_ERR_USERMSG, aText);
}
